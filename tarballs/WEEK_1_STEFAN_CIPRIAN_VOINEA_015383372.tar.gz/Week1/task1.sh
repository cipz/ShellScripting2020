#!/bin/bash

mkdir ShellScripting2020
cd ShellScripting2020
mkdir Week1
cd Week1