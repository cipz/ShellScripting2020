#!/bin/bash

url='https://man.cx/'
firefox $url$1