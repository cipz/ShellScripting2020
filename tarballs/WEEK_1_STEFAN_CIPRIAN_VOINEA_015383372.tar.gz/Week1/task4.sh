#!/bin/bash

rsync --archive /cs/home/tkt_cam/public_html/2018/12/01/ ShellScripting2020/Week1/ --stats