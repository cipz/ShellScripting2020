#!/bin/bash

date +%A.%Y.%m.%d