#!/bin/bash

# rsync-todays-Exactum-cam.sh

echo "rsync --archive /cs/home/tkt_cam/public_html/$(date +%Y/%m/%d)/~/ShellScripting2019/Week1/$(date +%A.%Y.%m.%d)"