#!/bin/bash

ls >out 2> error