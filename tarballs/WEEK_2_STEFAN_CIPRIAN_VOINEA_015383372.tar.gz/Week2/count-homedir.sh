#!/bin/bash

ls -p ~ | egrep -v /$ | wc -l