#!/bin/bash

ls ~ | grep 'e' | wc -l