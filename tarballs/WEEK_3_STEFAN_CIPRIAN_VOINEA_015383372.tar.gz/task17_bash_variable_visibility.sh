#!/bin/bash

echo $HISTCMD
echo $HOME
echo $PWD