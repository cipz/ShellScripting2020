#!/bin/bash

echo $@