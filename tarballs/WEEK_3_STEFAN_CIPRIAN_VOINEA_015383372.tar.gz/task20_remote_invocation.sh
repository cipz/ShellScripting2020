#!/bin/bash

ssh stefvoin@$1 $2